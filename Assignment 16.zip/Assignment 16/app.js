//  Chap 1:
// Q:1:Write a script to greet your website visitor using JS alert
// box.
// alert("Welcome to our website");
// Chap 1:
// // Q:2:
// Write a script to display following message on your web
// page:
// Ans:
// alert("Please Enter A valid Password");
// Chap 1:
// // Q:3:
// Ans:

// alert("Welcome to JS Land \n Happy Codding");
// Q4: Write a script to display following messages in sequence:
// Ans:
// alert("Welcome to JS land");
// alert("Prevet this page from creating additional dialouges");
// 5. Generate the following message through browser’s
// developer console:
// Ans:
// alert("Hello.. I can JS through my web browser console");



//    Chap 2:
// 1. Declare a variable called username:
// Ans:
// var username="Saad";
// console.log(username);
// 2. Declare a variable called myName & assign to it a string
// that represents your Full Name.
// Ans:
// var myName="Saad Ullah Malik";
// console.log(myName);
// 3. Write script to
// a) Declare a JS variable, titled message.
// b) Assign “Hello World” to variable message
// c) Display the message in alert box.
// Ans:
// var message="Hello World"
// alert(message);
// 4. Write a script to save student’s bio data in JS variables and
// show the data in alert boxes.
// Ans:
// var Name="Saad";
// alert(Name);
// var age=20;
// alert(age);
// var about="Saad Is Very Intelligent MashaAllah";
// alert(about);
// 5. Write a script to display the following alert using one JS
// variable:
// Ans:
// var pizza="Pizza \n Pizz \n Piz \n Pi \n P";
// alert(pizza);

// 6. Declare a variable called email and assign to it a string that
// represents your Email Address(e.g. example@example.com).
// Show the blow mentioned message in an alert box.(Hint: use
// string concatenation)
// Ans:

// var email=" My enail address is saadmalikm03@gmail.com";
// alert(email);
// 7. Declare a variable called book & give it the value “A
// smarter way to learn JavaScript”. Display the following
// message in an alert box:
// Ans:
// var book="A smarter Way to learn Javascrit";
// alert(book);
// Chap 3

// 1. Declare a variable called age & assign to it your age. Show
// your age in an alert box.
// Ans:

// var age="I am 20 Years"
// alert(age);


// 2. Declare & initialize a variable to keep track of how many
// times a visitor has visited a web page. Show his/her
// number of visits on your web page. For example: “You
// have visited this site N times”.
// Ans:


// var visits="You are visited n times on this website";
// alert(visits);


// 3. Declare a variable called birthYear & assign to it your
// birth year. Show the following message in your browser:
// Ans:

// var birthYear="My birth year is 2002 \n Data type of my declaredvariable is number";
// console.log(birthYear);



// 4. A visitor visits an online clothing store
// www.xyzClothing.com . Write a script to store in variables
// the following information:
// a. Visitor’s name
// b. Product title
// c. Quantity i.e. how many products a visitor wants to
// order
// Show the following message in your browser: “John
// Doe ordered 5 T-shirt(s) on XYZ Clothing store”.
// Ans:


// var information="Saad  purchasing clothes and they ordered the 3 products"
// console.log(information);




//   Chap 4:
// 1. Declare 3 variables in one statement
// Ans:

// var firstName="saad",lastname="Malik",age=20;

// 2. Declare 5 legal & 5 illegal variable names.
// Ans:


// 5 legal variable names:
// var 'firstName':;
// var 'userName';
// var '$Age';
// var '_name';
// var 'totalAmount';

// 5 Illegal variable names:

// 2ndPlace 
// my-variable
// my variable
// #count 
// let 

//    Chap 5:

// 1. Write a program that take two numbers & add them in a
// new variable. Show the result in your browser.
// Ans:


// var num1=30;
// var num2=40;
// var add=num1+num2;
// console.log(add);

// 2. Repeat task1 for subtraction, multiplication, division &
// modulus.
// Ans:

// For substraction:

// var num1=30;
// var num2=40;
// var sub=num1-num2;
// console.log(sub);

// For multiplication:

// var num1=30;
// var num2=40;
// var multiplication=num1*num2;
// console.log(multiplication);

//    for Division:
// var num1=30;
// var num2=40;
// var division=num1/num2;
// console.log(division);


// 4. Cost of one movie ticket is 600 PKR. Write a script to
// store
// ticket price in a variable & calculate the cost of buying 5
// tickets
// Ans:

// var ticketprice="600";
// var tickets="5";
// var totalAmount="ticketprice*5tickets";
// console.log(totalAmount);



// Chap 9 t0 11:


// var cityName=prompt("Enter the city Name");
// if (cityName.toLowerCase()==="Karachi"){
// alert("Welcome to the city of lights");
// }
// else{

//     alert("Welcome to "+cityName);
// }





// 2. Write a program to take “gender” as input from user. If the
// user is male, give the message: Good Morning Sir. If the
// user is female, give the message: Good Morning Ma’am.
// Ans:


// var gender=prompt("Enet your gender Gender")
// if(gender.toLowerCase()==="male"){
//     alert("Good Morning Sir")
// }
// else{(gender.toLowerCase()==="Female")
// alert("Good Morning Maam")
// }
// ;




// 3. Write a program to take input color of road traffic signal
// from the user & show the message according to this table:
// Signal color Message
// Red Must Stop
// Yellow Ready to move
// Green Move now

// Ans:



var signalColor = prompt('Enter the color of the traffic signal:');


var lowercaseColor = signalColor.toLowerCase();


if (lowercaseColor === 'red') {
    alert('Must Stop');
} else if (lowercaseColor === 'yellow') {
    alert('Ready to move');
} else if (lowercaseColor === 'green') {
    alert('Move now');
} else {
    alert('Invalid color entered.');
}


